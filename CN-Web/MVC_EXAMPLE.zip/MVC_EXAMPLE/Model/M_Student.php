<?php
    include_once("E_Student.php");
    class Model_Student
    {
        public function __construct(){}
        public function getAllStudent()
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu1');
            $sql = "SELECT * FROM sinhvien";
            $rs = mysqli_query($bienketnoi, $sql);
            $i = 0;
            while($row = mysqli_fetch_array($rs))
            {
                $id = $row['id'];
                $name = $row['name'];
                $age = $row['age'];
                $university =$row['university'];
                while($i != $id)
                {
                    $students[$i++] = new Entity_Student("", "", "", "");
                    //$i++;
                }
                $students[$i++] = new Entity_Student($id, $name, $age, $university);
            }
            return $students;
        }
        public function getStudentDetail($stid)
        {
            $allStudent = $this -> getAllStudent();
            return $allStudent[$stid];
        }
        public function checkID($id)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu1');
            $rs = mysqli_query($bienketnoi, "SELECT * FROM sinhvien");
            $i = 0;
            while($row = mysqli_fetch_array($rs))
            {
                if($row['id'] == $id)
                {
                    return 1;
                }
            }
            return 0;
        }
        public function addStudent($id, $name, $age, $university)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu1');
            $rs = mysqli_query($bienketnoi, "INSERT INTO sinhvien VALUE ('$id','$name','$age','$university')");
            return 1;
        }
        public function editStudent($id, $name, $age, $university)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu1');
            $rs = mysqli_query($bienketnoi, "UPDATE sinhvien SET name='$name', age='$age', university='$university' WHERE id='$id'");
            return 1;
        }
        public function deleteStudent($id)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu1');
            $rs = mysqli_query($bienketnoi, "DELETE FROM sinhvien WHERE id='$id'");
            return 1;
        }
        public function searchStudent($op, $txt)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu1');
            $rs = mysqli_query($bienketnoi, "SELECT * FROM sinhvien WHERE $op LIKE '%$txt%'");
            $i = 0;
            if($row = mysqli_fetch_array($rs))
            {
                do
                {
                    $id = $row['id'];
                    $name = $row['name'];
                    $age = $row['age'];
                    $university =$row['university'];
                    while($i != $id)
                    {
                        $students[$i++] = new Entity_Student("", "", "", "");
                        //$i++;
                    }
                    $students[$i++] = new Entity_Student($id, $name, $age, $university);
                }while($row = mysqli_fetch_array($rs));
                return $students;
            }
            else
            {
                return 0;
            }
        }
    }
?>