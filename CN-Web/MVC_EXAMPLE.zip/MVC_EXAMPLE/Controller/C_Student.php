<?php
    include_once("../Model/M_Student.php");
    class Ctrl_Student
    {
        public function invoke()
        {
            if(isset($_GET['mod1'])) //Add
            {
                if(isset($_REQUEST['submit']))
                {
                    $modelStudent = new Model_Student();
                    $student = $modelStudent -> addStudent($_REQUEST['id'], $_REQUEST['name'], $_REQUEST['age'], $_REQUEST['university']);
                    header("Location: C_Student.php");
                }
                elseif(isset($_REQUEST['checkID']))
                {
                    $modelStudent = new Model_Student();
                    $student = $modelStudent -> checkID($_REQUEST['ID']);
                    if($student == 1)
                    {
                        echo "ID đã tồn tại!";
                    }
                }
                else
                {
                    include_once("../View/AddStudent.html");
                }
            }
            elseif(isset($_GET['mod2'])) //Edit
            {
                if(isset($_REQUEST['id']))
                {
                    $modelStudent = new Model_Student();
                    $student = $modelStudent -> getStudentDetail($_GET['id']);
                    include_once("../View/EditStudentForm.html");
                    if(isset($_REQUEST['stid']))
                    {
                        $modelStudent = new Model_Student();
                        $student = $modelStudent -> editStudent($_REQUEST['id'], $_REQUEST['name'], $_REQUEST['age'], $_REQUEST['university']);
                        header("Location: C_Student.php?mod2='1'");
                    }
                }
                else
                {
                    $modelStudent = new Model_Student();
                    $studentList = $modelStudent -> getAllStudent();
                    include_once("../View/EditStudent.html");
                }
            }
            elseif(isset($_GET['mod3'])) //Delete
            {
                $modelStudent = new Model_Student();
                $studentList = $modelStudent -> getAllStudent();
                include_once("../View/DeleteStudent.html");
                if(isset($_REQUEST['id']))
                {
                    $modelStudent = new Model_Student();
                    $student = $modelStudent -> deleteStudent($_REQUEST['id']);
                    header("Location: C_Student.php?mod3='1'");
                }
            }
            elseif(isset($_GET['mod4'])) //Search
            {
                if(isset($_REQUEST['cbb']))
                {
                    $modelStudent = new Model_Student();
                    $studentList = $modelStudent -> searchStudent($_REQUEST['cbb'], $_REQUEST['txt']);
                    if($studentList)
                    {
                        include_once("../View/SearchStudentDetail.html");
                    }
                    else
                    {
                        echo '<script>
                            alert("Không tìm thấy thông tin này");
                        </script>';
                    }
                }
                else
                {
                    include_once("../View/SearchStudent.html");
                }

            }
            elseif(isset($_GET['stid']))
            {
                $modelStudent = new Model_Student();
                $student = $modelStudent -> getStudentDetail($_GET['stid']);
                include_once("../View/StudentDetail.html");
            }
            else
            {
                $modelStudent = new Model_Student();
                $studentList = $modelStudent -> getAllStudent();
                include_once("../View/StudentList.html");
            }
            
        }
    }
    $C_Student = new Ctrl_Student();
    $C_Student -> invoke();
?>