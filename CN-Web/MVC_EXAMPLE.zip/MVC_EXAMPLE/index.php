<html>
    <head>
        <meta charset="UTF-8"/>
        <title>MVC-EXAMPLE</title>
    </head>
    <body>
        <h1 align="center">VÍ DỤ MVC</h1>
        <h3>Chức năng</h3>
        <h3>1. <a href="Controller/C_Student.php">Xem sinh viên</a></h3>
        <h3>2. <a href="Controller/C_Student.php?mod1='1'">Chèn thông tin</a></h3>
        <h3>3. <a href="Controller/C_Student.php?mod2='1'">Cập nhật thông tin</a></h3>
        <h3>4. <a href="Controller/C_Student.php?mod3='1'">Xóa thông tin</a></h3>
        <h3>5. <a href="Controller/C_Student.php?mod4='1'">Tìm kiếm thông tin</a></h3>
    </body>
</html>