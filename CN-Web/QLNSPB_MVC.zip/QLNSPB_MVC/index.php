<html>
    <head>
        <title>Main</title>
        <meta charset="utf-8">
        <style>
            a{
                padding: 5px 0;
                display: block;
                margin: 0 15px;
                font-weight: 600;
                font-size: 14px;
                color: #1B3358;
                text-decoration: none;
                width: 200px;
                height: fit-content;
                align-items: center;
                border-bottom: 1px solid #eaeaea;
            }    
            a:hover{
                padding: 5px 15px;
                margin: 0%;
                box-sizing: border-box;
                background-color: #1B3358;
                color: white;
            } 
            .left{
                border: 1px solid #eaeaea;
                font-family: inherit;
                font-size: 100%;
                margin-bottom: 0;
                width: max-content;
            }
        </style>
    </head>
    <body>
        <div style="background-color: #1B3358;">
            <h3 style="text-align: center; color: white;">
                <marquee behavior="" direction="">CÔNG NGHỆ WEB: QUẢN LÝ NHÂN SỰ PHÒNG BAN - MVC - Phan Trần Nhật Hạ - 21Nh12</marquee>
            </h3>
        </div>
        <a href="Controller/C_QLNSPB.php?login='1'">Đăng nhập</a>
        <h3 style="text-align: left; color: #1B3358;">MENU</h3>
        <div class="left">
            <a href="Controller/C_QLNSPB.php?xemNV='1'" target="T3">1. Xem thông tin nhân viên</a>
            <a href="Controller/C_QLNSPB.php?xemPB='1'" target="T3">2. Xem thông tin phòng ban</a>
            <a href="Controller/C_QLNSPB.php?search='1'" target="T3">3. Tìm kiếm</a>
        </div>
    </body>
</html>