<?php
    include_once("../Model/M_QLNSPB.php");
    class Ctrl_QLNSPB
    {
        public function invoke()
        {
            if(isset($_REQUEST['login'])) 
            {
                include_once("../View/Login.html");
                if(isset($_REQUEST['submit']))
                {
                    $modelNhanvien = new Model_QLNSPB();
                    $nhanvien = $modelNhanvien -> login($_REQUEST['Username'], $_REQUEST['Password']);
                    if($nhanvien == '1')
                    {
                        header("Location: ../index_dn.php");
                    }
                    elseif($nhanvien == '2') //sai pass
                    {
                        echo '<script>
                            alert("Sai mật khẩu");
                        </script>';
                    }
                    else //sai user
                    {
                        echo '<script>
                            alert("Sai user");
                        </script>';
                    }
                }
            }
            elseif(isset($_REQUEST['xemNV'])) 
            {
                $modelNhanvien = new Model_QLNSPB();
                $nhanvien = $modelNhanvien -> getAllNV();
                include_once("../View/XemthongtinNV.html");
            }
            elseif(isset($_REQUEST['xemPB']))
            {
                $modelPhongban = new Model_QLNSPB();
                $phongban = $modelPhongban -> getAllPB();
                include_once("../View/XemthongtinPB.html");
            }
            elseif(isset($_REQUEST['search']))
            {
                if(isset($_REQUEST['cbb']))
                {
                    $modelNhanvien = new Model_QLNSPB();
                    $nhanvien = $modelNhanvien -> searchNV($_REQUEST['cbb'], $_REQUEST['txt']);
                    if($nhanvien)
                    {
                        include_once("../View/XemthongtinNV.html");
                    }
                    else
                    {
                        echo '<script>
                            alert("Không có nhân viên này");
                        </script>';
                        include_once("../View/Search.html");
                    }
                }
                else
                {
                    include_once("../View/Search.html");
                }
            }
            elseif(isset($_REQUEST['addNV']))
            {
                if(isset($_REQUEST['submit']))
                {
                    $modelNhanvien = new Model_QLNSPB();
                    $r = $modelNhanvien -> addNV($_REQUEST['idnv'], $_REQUEST['hoten'], $_REQUEST['idpb'], $_REQUEST['diachi']);
                    $nhanvien = $modelNhanvien -> getAllNV();
                    include_once("../View/XemthongtinNV.html");
                }
                elseif(isset($_REQUEST['checkIDNV']))
                {
                    $modelNhanvien = new Model_QLNSPB();
                    $r = $modelNhanvien -> checkIDNV($_REQUEST['IDNV']);
                    if($r == 1)
                    {
                        echo 'Mã nhân viên bị trùng!';
                    }
                }
                elseif(isset($_REQUEST['checkIDPB']))
                {
                    $modelPhongban = new Model_QLNSPB();
                    $r = $modelPhongban -> checkIDPB($_REQUEST['IDPB']);
                    if($r == 0)
                    {
                        echo 'Mã phòng ban không tồn tại!';
                    }
                }
                else
                {
                    include_once("../View/AddNV.html");
                }
            }
            elseif(isset($_REQUEST['addPB']))
            {
                if(isset($_REQUEST['submit']))
                {
                    $modelPhongban = new Model_QLNSPB();
                    $r = $modelPhongban -> addPB($_REQUEST['idpb'], $_REQUEST['tenpb'], $_REQUEST['mota']);
                    $phongban = $modelPhongban -> getAllPB();
                    include_once("../View/XemthongtinPB.html");
                }
                elseif(isset($_REQUEST['checkIDPB']))
                {
                    $modelPhongban = new Model_QLNSPB();
                    $r = $modelPhongban -> checkIDPB($_REQUEST['IDPB']);
                    if($r == 1)
                    {
                        echo 'Mã phòng đã tồn tại!';
                    }
                }
                else
                {
                    include_once("../View/AddPB.html");
                }
            }
            elseif(isset($_REQUEST['updatePB']))
            {
                if(isset($_REQUEST['idpb']))
                {
                    $modelPhongban = new Model_QLNSPB();
                    $phongban = $modelPhongban -> getPB($_REQUEST['idpb']);
                    include_once("../View/UpdatePBForm.html");
                    if(isset($_REQUEST['id']))
                    {
                        $modelPhongban = new Model_QLNSPB();
                        $phongban = $modelPhongban -> updatePB($_REQUEST['idpb'], $_REQUEST['tenpb'], $_REQUEST['mota']);  
                        header("Location: C_QLNSPB.php?updatePB='1'");
                    }
                }
                else
                {
                    $modelPhongban = new Model_QLNSPB();
                    $phongbanList = $modelPhongban -> getAllPB();
                    include_once("../View/UpdatePBList.html");
                }
            }
            elseif(isset($_REQUEST['deleteNV']))
            {
                if(isset($_REQUEST['idnv']))
                {
                    $modelNhanvien = new Model_QLNSPB();
                    $nhanvien = $modelNhanvien -> deleteNV($_REQUEST['idnv']);
                    header("Location: C_QLNSPB.php?deleteNV='1'");
                }
                else
                {
                    $modelNhanvien = new Model_QLNSPB();
                    $nhanvien = $modelNhanvien -> getAllNV();
                    include_once("../View/DeleteNV.html");
                }
            }
            elseif(isset($_REQUEST['deleteAllNV']))
            {
                if(isset($_REQUEST['submit']))
                {
                    $modelNhanvien = new Model_QLNSPB();
                    $nhanvien = $modelNhanvien -> getAllNV();
                    for($i = 1; $i <= sizeof($nhanvien); $i++)
                    {
                        $IDNV = $_REQUEST[$nhanvien[$i]->idNV];
                        if($IDNV != null)
                        {
                            $modelNhanvien -> deleteNV($IDNV);
                        }
                    }
                    header("Location: C_QLNSPB.php?deleteAllNV='1'");
                }
                else
                {
                    $modelNhanvien = new Model_QLNSPB();
                    $nhanvien = $modelNhanvien -> getAllNV();
                    include_once("../View/DeleteAllNV.html");
                }
            }
            else
            {
                header("Location: ../index.php");
            }
        }
    }
    $C_QLNSPB = new Ctrl_QLNSPB();
    $C_QLNSPB -> invoke();
?>