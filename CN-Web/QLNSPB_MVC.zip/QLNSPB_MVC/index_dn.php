<html>
    <head>
        <title>Main</title>
        <meta charset="utf-8">
        <style>
            a{
                padding: 5px 0;
                display: block;
                margin: 0 15px;
                font-weight: 600;
                font-size: 14px;
                color: #1B3358;
                text-decoration: none;
                width: 200px;
                height: fit-content;
                align-items: center;
                border-bottom: 1px solid #eaeaea;
            }    
            a:hover{
                padding: 5px 15px;
                margin: 0%;
                box-sizing: border-box;
                background-color: #1B3358;
                color: white;
            } 
            .left{
                border: 1px solid #eaeaea;
                font-family: inherit;
                font-size: 100%;
                margin-bottom: 0;
                width: max-content;
            }
        </style>
    </head>
    <body>
        <div style="background-color: #1B3358;">
            <h3 style="text-align: center; color: white;">
                <marquee behavior="" direction="">CÔNG NGHỆ WEB: QUẢN LÝ NHÂN SỰ PHÒNG BAN - MVC - Phan Trần Nhật Hạ - 21Nh12</marquee>
            </h3>
        </div>
        <a href="Controller/C_QLNSPB.php">Đăng xuất</a>
        <h3 style="text-align: left; color: #1B3358;">MENU</h3>
        <div class="left">
            <a href="Controller/C_QLNSPB.php?xemNV='1'">1. Xem thông tin nhân viên</a>
            <a href="Controller/C_QLNSPB.php?xemPB='1'">2. Xem thông tin phòng ban</a>
            <a href="Controller/C_QLNSPB.php?search='1'">3. Tìm kiếm</a>
            <a href="Controller/C_QLNSPB.php?addNV='1'">4. Thêm nhân viên</a>
            <a href="Controller/C_QLNSPB.php?addPB='1'">5. Thêm phòng ban</a>
            <a href="Controller/C_QLNSPB.php?updatePB='1'">6. Cập nhật PB</a>
            <a href="Controller/C_QLNSPB.php?deleteNV='1'">7. Xóa nhân viên</a>
            <a href="Controller/C_QLNSPB.php?deleteAllNV='1'">8. Xóa tất cả nhân viên</a>
        </div>
    </body>
</html>