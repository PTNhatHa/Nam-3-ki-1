<?php
class Entity_QLNSPB
{
    public $idNV;
    public $hoten;
    public $diachi;
    public $idPB;
    public $tenpb;
    public $mota;

    public function __construct($_idNV, $_hoten, $_diachi, $_idPB, $_tenpb, $_mota)
    {
        $this -> idNV = $_idNV;
        $this -> hoten = $_hoten;
        $this -> diachi = $_diachi;
        $this -> idPB = $_idPB;
        $this -> tenpb = $_tenpb;
        $this -> mota = $_mota;
    }
}
?>