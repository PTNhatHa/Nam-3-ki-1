<?php
    include_once("E_QLNSPB.php");
    class Model_QLNSPB
    {
        public function __construct(){}
        public function login($user, $pw)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu');
            $rs = mysqli_query($bienketnoi, "SELECT password FROM admin WHERE Username ='$user'");
            if($row = mysqli_fetch_array($rs, MYSQLI_BOTH))
            {
                if($pw==$row['password'])
                {
                    return 1;
                }
                else
                {
                    // Sai pass
                    return 2; 
                }
            }
            else
            {
                // Sai user
                return 0;
            }
        }
        public function getAllNV()
        {
            $link = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($link, 'dulieu');
            $rs = mysqli_query($link, "SELECT * FROM nhanvien");
            $i = 1;
            while($row = mysqli_fetch_array($rs))
            {
                $idNV = $row['IDNV'];
                $hoten = $row['Hoten'];
                $diachi = $row['Diachi'];
                $idPB = $row['IDPB'];
                $tenpb = null;
                $mota = null;
                $nhanviens[$i++] = new Entity_QLNSPB($idNV, $hoten, $diachi, $idPB, $tenpb, $mota);
            }
            return $nhanviens;
        }
        public function getAllPB()
        {
            $link = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($link, 'dulieu');
            $rs = mysqli_query($link, "SELECT * FROM phongban");
            $i = 1;
            while($row = mysqli_fetch_array($rs))
            {
                $idNV = null;
                $hoten = null;
                $diachi = null;
                $idPB = $row['IDPB'];
                $tenpb = $row['Tenpb'];
                $mota = $row['Mota'];
                $phongban[$i++] = new Entity_QLNSPB($idNV, $hoten, $diachi, $idPB, $tenpb, $mota);
            }
            return $phongban;
        }
        public function searchNV($tieuchi, $txt)
        {
            $link = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($link, 'dulieu');
            $rs = mysqli_query($link, "SELECT * FROM nhanvien WHERE $tieuchi LIKE '%$txt%'");
            $i = 1;
            if($row = mysqli_fetch_array($rs))
            {
                do
                {
                    $idNV = $row['IDNV'];
                    $hoten = $row['Hoten'];
                    $diachi = $row['Diachi'];
                    $idPB = $row['IDPB'];
                    $tenpb = null;
                    $mota = null;
                    $nhanviens[$i++] = new Entity_QLNSPB($idNV, $hoten, $diachi, $idPB, $tenpb, $mota);
                }while($row = mysqli_fetch_array($rs));
                return $nhanviens;
            }
            else
            {
                return 0;
            }
        }
        public function getPB($idpb)
        {
            $link = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($link, 'dulieu');
            $rs = mysqli_query($link, "SELECT * FROM phongban WHERE IDPB = '$idpb'");
            $i = 1;
            while($row = mysqli_fetch_array($rs))
            {
                $idNV = null;
                $hoten = null;
                $diachi = null;
                $idPB = $row['IDPB'];
                $tenpb = $row['Tenpb'];
                $mota = $row['Mota'];
                $phongban[$i++] = new Entity_QLNSPB($idNV, $hoten, $diachi, $idPB, $tenpb, $mota);
            }
            return $phongban;
        }
        public function updatePB($idpb, $tenpb, $mota)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu');
            $rs = mysqli_query($bienketnoi, "UPDATE phongban SET Tenpb='$tenpb', Mota='$mota' WHERE IDPB='$idpb'");
            return 1;
        }
        public function deleteNV($idnv)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu');
            $rs = mysqli_query($bienketnoi, "DELETE FROM nhanvien WHERE IDNV='$idnv'");
            return 1;
        }
        public function addNV($idnv, $hoten, $idpb, $diachi)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu');
            $rs = mysqli_query($bienketnoi, "INSERT INTO nhanvien VALUE ('$idnv','$hoten','$idpb','$diachi')");
            return 1;
        }
        public function addPB($idpb, $tenpb, $mota)
        {
            $bienketnoi = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($bienketnoi, 'dulieu');
            $rs = mysqli_query($bienketnoi, "INSERT INTO phongban VALUE ('$idpb','$tenpb','$mota')");
            return 1;
        }
        public function checkIDNV($idnv)
        {
            $link = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($link, 'dulieu');
            $rs = mysqli_query($link, "SELECT * FROM nhanvien");
            while($row = mysqli_fetch_array($rs))
            {
                if($idnv == $row['IDNV'])
                {
                    return 1;
                    exit();
                }
            }
            return 0;
        }
        public function checkIDPB($idpb)
        {
            $link = mysqli_connect('localhost', 'root','');
            $db_selected = mysqli_select_db($link, 'dulieu');
            $rs = mysqli_query($link, "SELECT * FROM phongban WHERE IDPB = '$idpb'");
            while($row = mysqli_fetch_array($rs))
            {
                if($idpb == $row['IDPB'])
                {
                    return 1;
                    exit();
                }
            }
            return 0;
        }
    }
?>