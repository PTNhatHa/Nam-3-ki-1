<html>
    <head>
        <style>
            table{
                margin-left: auto;
                margin-right: auto;
                width: 20%;
            }
        </style>
    </head>
    <body>
        <form action="" method="post">
            <table>
                <caption style="color: #1B3358;"><h3>Chèn phòng ban</h3></caption>
                    <tr>
                        <td>IDPB</td>
                        <td><input type="text" name="maPB"></td>
                    </tr>
                    <tr>
                        <td>Tên PB</td>
                        <td><input type="text" name="tenPB"></td>
                    </tr>

                    <tr>
                        <td>Mô tả</td>
                        <td><input type="text" name="mota"></td>
                    </tr>
                    <tr>
                        <td></td>
                    <td>
                        <input type="submit" name="submit" value="Cập nhật">
                        <input type="reset" value="Reset">
                    </td>
                    </tr>
            </table>
        </form>
    </body>
</html>
<?php
    if(isset($_POST['submit'])) // kiểm tra form đã được submit hay chưa
    {
        $bienketnoi = mysqli_connect('localhost', 'root','');
        $db_selected = mysqli_select_db($bienketnoi, 'dulieu'); //mở CSDL
        $rs = mysqli_query($bienketnoi, "SELECT * FROM phongban");
        while($row = mysqli_fetch_array($rs, MYSQLI_BOTH))
        {
            if($_POST['maPB'] == $row['IDPB'])
            {
                echo '<script>
                        alert("Mã phòng ban bị trùng. Vui lòng nhập lại!");
                    </script>';
                exit();
            }
        }
        echo 
        '<script>
            location.href = "xulichenPB.php?IDPB='.$_POST['maPB'].'&tenPB='.$_POST['tenPB'].'&mota='.$_POST['mota'].'";
        </script>';
        exit();
        mysqli_close($bienketnoi);
        mysqli_free_result($rs);
    }
?>