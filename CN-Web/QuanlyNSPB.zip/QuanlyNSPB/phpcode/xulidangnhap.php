<?php
    $user = $_REQUEST['Username'];
    $pw = $_REQUEST['Password'];
    $bienketnoi = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($bienketnoi, 'dulieu'); //mở CSDL
    $rs = mysqli_query($bienketnoi, "SELECT password FROM admin WHERE Username ='$user'");
    if($user == "")
    {
        $message = "Vui lòng nhập username";
            echo "<script>alert('$message');</script>";
            echo '<script>
            location.href = "dangnhap.php";
            </script>';
    }
    if($pw == "")
    {
        $message = "Vui lòng nhập password";
            echo "<script>alert('$message');</script>";
            echo '<script>
            location.href = "dangnhap.php";
            </script>';
    }
    if($row = mysqli_fetch_array($rs, MYSQLI_BOTH))
    {
        if($pw==$row['password'])
        {
            $message = "Đăng nhập thành công";
            echo "<script>alert('$message');</script>";
            echo '<script>
            location.href = "../html/index_dn.html";
            </script>';
        }
        else
        {
            $message = "Sai pass";
            echo "<script>alert('$message');</script>";
            echo '<script>
            location.href = "dangnhap.php";
            </script>';
        }
    }
    else
    {
        $message = "Sai username";
            echo "<script>alert('$message');</script>";
            echo '<script>
            location.href = "dangnhap.php";
            </script>';
    }
?>