<html>
    <head>
        <style>
            table{
                margin-left: auto;
                margin-right: auto;
                width: 20%;
            }
        </style>
    </head>
    <body>
        <form action="" method="post">
            <table>
                <caption style="color: #1B3358;"><h3>Chèn nhân viên</h3></caption>
                    <tr>
                        <td>IDNV</td>
                        <td><input type="text" name="maNV"></td>
                    </tr>
                    <tr>
                        <td>Họ tên</td>
                        <td><input type="text" name="hoten"></td>
                    </tr>
                    <tr>
                        <td>IDPB</td>
                        <td><input type="text" name="maPB"></td>
                    </tr>
                    <tr>
                        <td>Địa chỉ</td>
                        <td><input type="text" name="diachi"></td>
                    </tr>
                    <tr>
                        <td></td>
                    <td>
                        <input type="submit" name="submit" value="Cập nhật">
                        <input type="reset" value="Reset">
                    </td>
                    </tr>
            </table>
        </form>
    </body>
</html>
<?php
    if(isset($_POST['submit'])) // kiểm tra form đã được submit hay chưa
    {
        $bienketnoi = mysqli_connect('localhost', 'root','');
        $db_selected = mysqli_select_db($bienketnoi, 'dulieu'); //mở CSDL
        $rs1 = mysqli_query($bienketnoi, "SELECT * FROM nhanvien");
        $rs2 = mysqli_query($bienketnoi, "SELECT * FROM phongban");
        while($row = mysqli_fetch_array($rs1, MYSQLI_BOTH))
        {
            if($_POST['maNV'] == $row['IDNV'])
            {
                echo '<script>
                        alert("Mã nhân viên bị trùng. Vui lòng nhập lại!");
                    </script>';
                exit();
            }
        }
        while($row = mysqli_fetch_array($rs2, MYSQLI_BOTH))
        {
            if($_POST['maPB'] == $row['IDPB'])
            {
                echo 
                '<script>
                    location.href = "xulichenNV.php?IDNV='.$_POST['maNV'].'&hoten='.$_POST['hoten'].'&IDPB='.$_POST['maPB'].'&diachi='.$_POST['diachi'].'";
                </script>';
                exit();
            }
        }
        echo 
        '<script>
            alert("Không tồn tại phòng ban này. Vui lòng nhập lại!");
        </script>';
        mysqli_close($bienketnoi);
        mysqli_free_result($rs1);
        mysqli_free_result($rs2);
    }
?>