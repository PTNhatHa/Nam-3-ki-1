<html>
    <head>
    <title>Tìm kiếm</title>
        <meta charset="utf-8">
    </head>
    <body>
        <form name="timkiem" action="xulitimkiem.php" method="post">
            <h3 style="text-align: center; color: #1B3358;">Tìm kiếm</h3>
            <div style="width: 250px; margin-left: auto; margin-right: auto;">
                <div>
                    <input type="radio" name="tieuchi" value="IDNV">IDNV
                    <input type="radio" name="tieuchi" value="Hoten">Họ tên
                    <input type="radio" name="tieuchi" value="Diachi">Địa chỉ
                </div>
                <div>
                    <input type="text" name="txt" value="">
                    <input type="submit" name="btOK" value="OK">
                    <input type="reset" name="btExit" value="Reset">
                </div>
            </div>
        </form>
    </body>
</html>
