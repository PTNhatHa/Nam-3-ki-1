<?php
    $mapb = $_REQUEST['IDPB'];
    $bienketnoi = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($bienketnoi, 'dulieu'); //mở CSDL

    if($mapb == "") $rs = mysqli_query($bienketnoi, "SELECT * FROM nhanvien"); //truy xuất DL
    else $rs = mysqli_query($bienketnoi, "SELECT * FROM nhanvien WHERE IDPB='$mapb'");

    $num_rows = mysqli_num_rows($rs); //trả về số bảng ghi select được
    echo '<table border="1" width="100%">';
    echo '<caption>Du lieu bang Nhan vien</caption>';
    echo '<TR><TH>IDNV</TH><TH>Ho ten</TH><TH>IDPB</TH><TH>Dia chi</TH></TR>';
    while($row = mysqli_fetch_array($rs, MYSQLI_BOTH)) //đọc bảng ghi - trả về False nếu không còn giá trị(bảng ghi) tiếp theo
    {
        echo 
            '<TR>
                <TD>'.$row['IDNV'].'</TD>
                <TD>'.$row['Hoten'].'</TD>
                <TD>'.$row['IDPB'].'</TD>
                <TD>'.$row['Diachi'].'</TD>
            <TR>
        ';
    }
    echo '</table>';
    mysqli_close($bienketnoi); //đóng CSDL
    mysqli_free_result($rs);
?>