<?php
    $tieuchi = $_REQUEST['tieuchi'];
    $txt = $_REQUEST['txt'];
    $bienketnoi = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($bienketnoi, 'dulieu');

    if($txt == "") $rs = mysqli_query($bienketnoi, "SELECT * FROM nhanvien");
    else $rs = mysqli_query($bienketnoi, "SELECT * FROM nhanvien WHERE $tieuchi LIKE '%$txt%'");
    echo '<table border="1" width="100%">';
    echo '<caption>Du lieu bang Nhan vien</caption>';
    echo '<TR><TH>IDNV</TH><TH>Ho ten</TH><TH>IDPB</TH><TH>Dia chi</TH></TR>';
    while($row = mysqli_fetch_array($rs, MYSQLI_BOTH))
    {
        echo 
            '<TR>
                <TD>'.$row['IDNV'].'</TD>
                <TD>'.$row['Hoten'].'</TD>
                <TD>'.$row['IDPB'].'</TD>
                <TD>'.$row['Diachi'].'</TD>
            <TR>
        ';
    }
    echo '</table>';
    mysqli_close($bienketnoi);
    mysqli_free_result($rs);
?>