<?php
    $maPB = $_REQUEST['IDPB'];
    $tenPB = $_REQUEST['tenPB'];
    $mota = $_REQUEST['mota'];
    $bienketnoi = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($bienketnoi, 'dulieu'); //mở CSDL
    $rs = mysqli_query($bienketnoi, "INSERT INTO phongban VALUE ('$maPB','$tenPB','$mota')");
    header("Location: xemthongtinPB.php");
?>