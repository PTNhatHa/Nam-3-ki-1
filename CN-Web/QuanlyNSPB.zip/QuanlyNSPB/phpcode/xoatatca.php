<?php
    $link = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($link, 'dulieu');
    $rs = mysqli_query($link, "SELECT * FROM nhanvien");
    echo '<form action="xulixoatatca.php" method="post">';
    echo '<table border="1" width="100%">';
    echo '<caption>Du lieu bang Nhan vien</caption>';
    echo '<TR><TH>IDNV</TH><TH>Ho ten</TH><TH>IDPB</TH><TH>Dia chi</TH><TH>Chon</TH></TR>';
    while($row = mysqli_fetch_array($rs, MYSQLI_BOTH))
    {
        echo 
            '<TR>
                <TD>'.$row['IDNV'].'</TD>
                <TD>'.$row['Hoten'].'</TD>
                <TD>'.$row['IDPB'].'</TD>
                <TD>'.$row['Diachi'].'</TD>
                <TD><input type="checkbox" name='.$row['IDNV'].' value='.$row['IDNV'].'></TD>
            <TR>
        ';
    }
    echo '<TR><TD colspan="4" align="right"><input type="submit" value="Xóa tất cả"></TD><TR>';
    echo '</TABLE>';
    mysqli_close($link);
    mysqli_free_result($rs);
?>