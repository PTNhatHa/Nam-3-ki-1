<?php
    $maNV = $_REQUEST['IDNV'];
    $hoten = $_REQUEST['hoten'];
    $maPB = $_REQUEST['IDPB'];
    $diachi = $_REQUEST['diachi'];
    $bienketnoi = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($bienketnoi, 'dulieu'); //mở CSDL
    $rs = mysqli_query($bienketnoi, "INSERT INTO nhanvien VALUE ('$maNV','$hoten','$maPB','$diachi')");
    header("Location: xemthongtinNV.php");
?>