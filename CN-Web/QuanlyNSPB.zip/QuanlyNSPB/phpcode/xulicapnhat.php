<?php
    $mapb = $_REQUEST['IDPB'];
    $tenpb = $_REQUEST['tenPB'];
    $motapb = $_REQUEST['motaPB'];
    $bienketnoi = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($bienketnoi, 'dulieu'); //mở CSDL
    $rs = mysqli_query($bienketnoi, "UPDATE phongban SET Tenpb='$tenpb', Mota='$motapb' WHERE IDPB='$mapb'");
    header("Location: capnhat.php");
?>