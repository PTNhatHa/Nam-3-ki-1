<?php
    $myID = $_REQUEST['IDNV'];
    $bienketnoi = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($bienketnoi, 'dulieu'); //mở CSDL
    $rs = mysqli_query($bienketnoi, "DELETE FROM nhanvien WHERE IDNV='$myID'");
    header("Location: xoa.php");
?>