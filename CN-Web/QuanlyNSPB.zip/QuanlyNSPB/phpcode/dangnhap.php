<html>
    <head>
        <style>
            table{
                margin-left: auto;
                margin-right: auto;
                width: 20%;
            }
        </style>
    </head>
    <body>
        <form name="formlogin" method="post" action="xulidangnhap.php">
            <table>
                <caption><h3 style="color: #1B3358;">Đăng nhập</h3></caption>
                <tr>
                    <td>Username</td>
                    <td>
                        <input type="text" name="Username" value="">
                    </td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td>
                        <input type="password" name="Password" value="">
                    </td>
                </tr>
            </table>
            <table>
                <tr>
                    <td style="text-align: center">
                        <input type="submit" name="buttonOK" value="OK">
                        <input type="reset" name="buttonCancel" value="Reset">
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>
