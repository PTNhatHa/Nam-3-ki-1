<?php
    $link = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($link, 'dulieu');
    $rs = mysqli_query($link, "SELECT * FROM phongban");
    echo '<table border="1" width="100%"';
    echo '<caption>Du lieu bang Phong ban</caption>';
    echo '<TR><TH>IDPB</TH><TH>Ten phong ban</TH><TH>Mo ta</TH><TH>Xem nhan vien</TH></TR>';
    while($row = mysqli_fetch_array($rs, MYSQLI_BOTH))
    {
        echo 
            '<TR>
                <TD>'.$row['IDPB'].'</TD>
                <TD>'.$row['Tenpb'].'</TD>
                <TD>'.$row['Mota'].'</TD>
                <TD style="text-align: center"><a href="form_capnhat.php?IDPB='.$row['IDPB'].'">xxx</a></TD>
            </TR>
        ';
    }
    echo '</TABLE>';
    mysqli_close($link);
    mysqli_free_result($rs);
?>