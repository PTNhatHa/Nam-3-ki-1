<?php
    $link = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($link, 'dulieu');
    $rs = mysqli_query($link, "SELECT * FROM nhanvien");
    echo '<table border="1" width="100%">';
    echo '<caption>Du lieu bang Nhan vien</caption>';
    echo '<TR><TH>IDNV</TH><TH>Ho ten</TH><TH>IDPB</TH><TH>Dia chi</TH><TH>Xoa</TH></TR>';
    while($row = mysqli_fetch_array($rs, MYSQLI_BOTH))
    {
        echo 
            '<TR>
                <TD>'.$row['IDNV'].'</TD>
                <TD>'.$row['Hoten'].'</TD>
                <TD>'.$row['IDPB'].'</TD>
                <TD>'.$row['Diachi'].'</TD>
                <TD style="text-align: center"><a href="xulixoa.php?IDNV='.$row['IDNV'].'">xxx</a></TD>
            <TR>
        ';
    }
    echo '</TABLE>';
    mysqli_close($link);
    mysqli_free_result($rs);
?>