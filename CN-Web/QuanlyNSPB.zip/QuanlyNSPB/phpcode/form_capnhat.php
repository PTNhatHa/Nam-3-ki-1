<?php
    $mapb = $_REQUEST['IDPB']; //nhận maPB từ capnhat.php
    $bienketnoi = mysqli_connect('localhost', 'root','');
    $db_selected = mysqli_select_db($bienketnoi, 'dulieu'); //mở CSDL
    $rs = mysqli_query($bienketnoi, "SELECT * FROM phongban WHERE IDPB='$mapb'");
    $row = mysqli_fetch_array($rs, MYSQLI_BOTH);
?>
<html>
    <head>
        <style>
            table{
                margin-left: auto;
                margin-right: auto;
                width: 20%;
            }
        </style>
    </head>
    <body>
        <form action='xulicapnhat.php?IDPB=<?php echo $row['IDPB']; ?>' method='post'>
            <table>
                <caption style="color: #1B3358;"><h3>Form cập nhật</h3></caption>
                 <tr>
                    <td>IDPB</td>
                    <td><input type="text" name="maPB" value='<?php echo $row['IDPB']; ?>' readonly></td>
                 </tr>
                 <tr>
                    <td>Tên PB</td>
                    <td><input type="text" name="tenPB" value='<?php echo $row['Tenpb']; ?>'></td>
                 </tr>
                 <tr>
                    <td>Mô tả</td>
                    <td><input type="text" name="motaPB" value='<?php echo $row['Mota']; ?>'></td>
                 </tr>
                 <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Cập nhật">
                        <input type="button" value="Hủy">
                    </td>
                 </tr>
            </table>
        </form>
    </body>
</html>