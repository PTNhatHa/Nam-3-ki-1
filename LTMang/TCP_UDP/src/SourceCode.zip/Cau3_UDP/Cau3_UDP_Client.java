package Cau3_UDP;

import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Cau3_UDP_Client extends JFrame{

	private TextArea input, output;
	static DatagramSocket clientSocket;
	
	public static void main(String[] args) throws IOException {
		clientSocket = new DatagramSocket();
		new Cau3_UDP_Client();
	}
	
	Cau3_UDP_Client()
	{
		this.setTitle("Client Fibonaci");
		this.setSize(500, 500);
		this.setDefaultCloseOperation(3);
		this.setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		
		JLabel t1 = new JLabel("Output");
		this.add(t1);
		output = new TextArea();
		output.setEditable(false);
		this.add(output);
		JLabel t2 = new JLabel("Input");
		this.add(t2);
		input = new TextArea();
		this.add(input);
		JButton b = new JButton("Send");
		
		
		b.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					InetAddress IPAddress = InetAddress.getByName("localhost");
					byte[] sendData = new byte[1024];
					byte[] receiveData = new byte[1024];
					String msg = input.getText();
					output.append("\n" + msg + "\n");
					sendData = msg.getBytes();
					DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 7000);
					clientSocket.send(sendPacket);
					new Thread(new Runnable() {
						public void run() {
							try {
								while(true)
								{
									DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
									clientSocket.receive(receivePacket);
									String remess = new String(receivePacket.getData());
									if(!remess.trim().equals("0"))
									{
										output.append(input.getText() + " là số Fibonaci thứ " + remess);
										output.append("\n" + "Vui lòng ngừng gửi!\n");
										//input.setVisible(false);
									}
									input.setText("");
									Thread.sleep(1000);
								}
								
							} catch (IOException | InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}).start();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		this.add(b);
		setVisible(true);
	}
}
