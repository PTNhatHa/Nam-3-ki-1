package UDP_Xulichuoi_GUI;

import java.io.*;
import java.net.*;
import java.lang.*;

public class UDP_Xulichuoi_GUI_Server {

	public static void main(String[] args) throws Exception
	{
		DatagramSocket serverSocket = new DatagramSocket(7000);
		System.out.println("Server is started");
		while(true)
		{
			new ClientHandlder(serverSocket).start();
		}
	}
}
class ClientHandlder extends Thread {
	DatagramSocket serverSocket;
	byte[] sendData;
	byte[] receiveData;
	
	public ClientHandlder(DatagramSocket serverSocket) throws IOException{
		this.serverSocket = serverSocket;
		sendData = new byte[1024];
		receiveData = new byte[1024];
	}
	public void run()
	{
		try {
			while(true)
			{
				DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
				serverSocket.receive(receivePacket);
				InetAddress IPAddress = receivePacket.getAddress();
				
				int port = receivePacket.getPort();
				
				String request = new String(receivePacket.getData(), 0, receivePacket.getLength());
				// Xử lí dl
				String msg = chuoinguoc(request) + "\n" 
						+ chuthuong(request) + "\n" + chuhoa(request) + "\n" + hoathuong(request) + "\n"
						+ demtu(request) + "\n";
				sendData = msg.getBytes();
				DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
				serverSocket.send(sendPacket);
			}
		} catch (IOException e) {
			//e.printStackTrace();
		}
	}
	public static String chuoinguoc(String s)
	{
		String ch = "";
		char[] c = s.toCharArray();
        for(int i = c.length - 1; i >= 0; i--) 
        {
            ch += c[i];
        }
		return ch;
	}
	public static String chuhoa(String s)
	{
		String ch = "";
		char[] c = s.toCharArray();
        for(int i = 0; i < c.length; i++) 
        {
            if(c[i] >= 97 && c[i] <= 122)
            {
                c[i] -= 32;
            }
        }
        ch = String.valueOf(c);
		return ch;
	}
	public static String chuthuong(String s)
	{
		String ch = "";
		char[] c = s.toCharArray();
        for(int i = 0; i < c.length; i++) 
        {
            if(c[i] >= 65 && c[i] <= 90)
            {
                c[i] += 32;
            }
        }
        ch = String.valueOf(c);
		return ch;
	}
	public static String hoathuong(String s)
	{
		String ch = "";
		char[] c = s.toCharArray();
        for(int i = 0; i < c.length; i++)
        {
            if(c[i] >= 97 && c[i] <= 122)
            {
                c[i] -= 32;
            }
            else
            {
            	if(c[i] >= 65 && c[i] <= 90)
            	{
                    c[i] += 32;
            	}
            }
        }
        ch = String.valueOf(c);
		return ch;
	}
	public static String demtu(String s)
	{
		String ch = "";
		char[] c = s.toCharArray();
		// u e o a i
		int d1=0, d2=0, d3=0, d4=0, d5=0;
        for(int i = 0; i < c.length; i++) 
        {
        	if(String.valueOf(c[i]).equalsIgnoreCase("u")) d1++;
        	if(String.valueOf(c[i]).equalsIgnoreCase("e")) d2++;
        	if(String.valueOf(c[i]).equalsIgnoreCase("o")) d3++;
        	if(String.valueOf(c[i]).equalsIgnoreCase("a")) d4++;
        	if(String.valueOf(c[i]).equalsIgnoreCase("i")) d5++;
        }
        String[] substring = s.split("\\s+");
        int sotu = substring.length;
        ch = "So tu co trong chuoi la: " + sotu + "\n";
        if(d1 != 0) ch += "So nguyen am u trong chuoi la: " + d1 + "\n";
        if(d2 != 0) ch += "So nguyen am e trong chuoi la: " + d2 + "\n";
        if(d3 != 0) ch += "So nguyen am o trong chuoi la: " + d3 + "\n";
        if(d4 != 0) ch += "So nguyen am a trong chuoi la: " + d4 + "\n";
        if(d5 != 0) ch += "So nguyen am i trong chuoi la: " + d5 + "\n";
		return ch;
	}
}
	
