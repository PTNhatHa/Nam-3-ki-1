package UDP_CSDL;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class UDP_CSDL_Server {

	public static void main(String[] args) throws Exception {
		DatagramSocket serverSocket = new DatagramSocket(7000);
		System.out.println("Server is started");
		while(true)
		{
			new ClientHandlder(serverSocket).start();
		}
	}

}
class ClientHandlder extends Thread {
	DatagramSocket serverSocket;
	byte[] receiveData;
	byte[] sendData;
	
	public ClientHandlder(DatagramSocket serverSocket) throws IOException{
		this.serverSocket = serverSocket;
		receiveData = new byte[1024];
		sendData = new byte[1024];
	}
	public void run(){
		try {
			while(true) {
				DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
				serverSocket.receive(receivePacket);
				InetAddress IPAddress = receivePacket.getAddress();
				int port = receivePacket.getPort();
				String string = new String(receivePacket.getData(), 0, receivePacket.getLength());
				
				//ket noi CSDL
				String url = "jdbc:mysql://localhost:3306/dulieu";
				Connection con = (Connection) DriverManager.getConnection(url,"root","");
				Class.forName("com.mysql.cj.jdbc.Driver");
				Statement stmt = con.createStatement();
				String sql = "select * from " + string;
				ResultSet rs = stmt.executeQuery(sql);
				ResultSetMetaData rsmd = rs.getMetaData();
				int socot = rsmd.getColumnCount();
				String text = "";
				while(rs.next()) 
				{
					for(int i = 1; i <= socot; i++)
					{
						text += rs.getObject(i) + " ";
					}
					text += "\n"; 
				}
				
				sendData = text.getBytes();
				DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
				serverSocket.send(sendPacket);
				rs.close();
				stmt.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Kết nối CSDL thất bại!");
			e.printStackTrace();
		}
	}
	
}
