package UDP_Chat;

import java.awt.FlowLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class UDP_Chat_Client extends JFrame  {
	TextArea output;
	JTextField input;
	static DatagramSocket clientSocket;
	static byte[] sendData = new byte[1024];
	byte[] receiveData = new byte[1024];
	
	public static void main(String[] args) throws Exception  {
		try {
			clientSocket = new DatagramSocket();
			InetAddress IPAddress = InetAddress.getByName("localhost");
			String msg = "Client is started";
			sendData = msg.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 7000);
			clientSocket.send(sendPacket);
			
			UDP_Chat_Client chat = new UDP_Chat_Client();
			chat.setVisible(true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	UDP_Chat_Client()
	{
		this.setTitle("Client");
		this.setSize(500, 300);
		this.setDefaultCloseOperation(3);
		this.setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		
		output = new TextArea();
		output.setEditable(false);
		this.add(output);

		JPanel p2 = new JPanel();
		p2.setLayout(new FlowLayout());
		input = new JTextField(45);
		p2.add(input);
		JButton b1 = new JButton("Send");

		new Thread(new Runnable() {
            public void run() {
                try {
                	while(true) {
                    	DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
						clientSocket.receive(receivePacket);
						String remess = new String(receivePacket.getData());
						output.append("\n" + remess);
						input.setText("");
                        Thread.sleep(100);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        }).start();	
		
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					InetAddress IPAddress = InetAddress.getByName("localhost");
					String msg = input.getText();
					sendData = msg.getBytes();
					DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 7000);
					clientSocket.send(sendPacket);

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		JButton b2 = new JButton("Close");
		b2.addActionListener((ActionListener) new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		p2.add(b1);
		p2.add(b2);
		this.add(p2);
	}
}
